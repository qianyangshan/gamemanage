#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
更新第一步 分发文件
'''
import baseFun
import multiprocessing
from webgame.settings import gamewebvar


def pushfile(user,ip):
    baseFun.writelog(user,'&&')
    script = "cd /data/pythonscript; ./updatePushFile.py '%s'"%(gamewebvar['rootIp'])
    ret = baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg'])
    



def upload(user,iplist):
    pool = multiprocessing.Pool(processes=len(iplist))
    for key,inip in iplist.items():
        pool.apply_async(pushfile, (user,inip))
    pool.close()
    pool.join()
    baseFun.writelog(user,'[32mupload file finished[0m')
