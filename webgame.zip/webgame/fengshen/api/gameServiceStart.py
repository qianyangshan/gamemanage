#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
开启game
'''
import baseFun
import multiprocessing

def start(user,ip,sid):
    '''
    baseFun.writelog(user,'&&')
    script = 'cd /data/pythonscript;./serviceGameStart.py %s'%(sid)
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg']) 
    '''
    

def gameStart(user,iplist):
    baseFun.writelog(user,'&&')
    pool = multiprocessing.Pool(processes=len(iplist))
    for inip,sid in iplist.items():
        pool.apply_async(start, (user,inip,sid))
    pool.close()
    pool.join()
