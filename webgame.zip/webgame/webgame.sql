-- MySQL dump 10.13  Distrib 5.6.34, for Linux (x86_64)
--
-- Host: localhost    Database: webgame
-- ------------------------------------------------------
-- Server version	5.6.34-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Crossinfo`
--

DROP TABLE IF EXISTS `Crossinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Crossinfo` (
  `cross_id` int(11) NOT NULL,
  `install_id` int(11) NOT NULL,
  `platform` varchar(20) NOT NULL,
  `in_ip` varchar(100) NOT NULL,
  `out_ip` varchar(100) NOT NULL,
  `open_time` datetime(6) NOT NULL,
  `subType` int(11) NOT NULL,
  PRIMARY KEY (`cross_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Crossinfo`
--

LOCK TABLES `Crossinfo` WRITE;
/*!40000 ALTER TABLE `Crossinfo` DISABLE KEYS */;
INSERT INTO `Crossinfo` VALUES (50000,1,'37','10.151.148.181','183.2.218.69','2017-03-22 17:04:15.000000',3),(65001,2,'37','10.151.148.181','183.2.218.69','2017-03-22 17:04:53.000000',4);
/*!40000 ALTER TABLE `Crossinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Serverinfo`
--

DROP TABLE IF EXISTS `Serverinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Serverinfo` (
  `server_id` smallint(5) NOT NULL,
  `platform_id` int(6) NOT NULL,
  `install_id` tinyint(2) NOT NULL,
  `host_name` varchar(100) DEFAULT NULL,
  `platform` varchar(20) NOT NULL,
  `in_ip` varchar(100) NOT NULL,
  `out_ip` varchar(100) NOT NULL,
  `open_time` datetime(6) NOT NULL,
  `hf_time` datetime(6) DEFAULT NULL,
  `is_hf` tinyint(1) NOT NULL DEFAULT '0',
  `hf_target` smallint(5) DEFAULT NULL,
  `is_remove` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Serverinfo`
--

LOCK TABLES `Serverinfo` WRITE;
/*!40000 ALTER TABLE `Serverinfo` DISABLE KEYS */;
INSERT INTO `Serverinfo` VALUES (1,50001,1,'s1.fengshen.lingyunetwork.com','37','10.151.148.181','183.131.148.181','2017-05-11 15:30:47.000000',NULL,0,NULL,0),(2,50002,2,'s1.fengshen.lingyunetwork.com','37','10.151.148.181','183.131.148.181','2017-05-11 15:30:47.000000',NULL,0,NULL,0),(3,50003,3,'s1.fengshen.lingyunetwork.com','37','10.151.148.181','183.131.148.181','2017-05-11 15:30:47.000000',NULL,0,NULL,0);
/*!40000 ALTER TABLE `Serverinfo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissi_permission_id_84c5c92e_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group_permissi_permission_id_84c5c92e_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  `type` tinyint(2) DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permissi_content_type_id_2f476e4b_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'creategame',1,'添加新服',1,1),(2,'creategameagain',1,'老服配服',1,1),(3,'createcross',1,'添加跨服',1,1),(4,'removegame',1,'移除合服',1,1),(5,'transfergame',1,'迁移game',1,1),(6,'transfercross',1,'迁移cross',1,1),(7,'initserver',1,'服务器初始化',1,0),(8,'cleandb',1,'游戏清档',1,0),(9,'gameprocess',1,'game进程管理',2,1),(10,'crossprocess',1,'cross进程管理',2,1),(11,'uploadfile',1,'上传更新文件',3,1),(12,'stopservice',1,'停止服务',3,1),(13,'updategame',1,'更新game',3,1),(14,'updatecross',1,'更新cross',3,1),(15,'updatedata',1,'更新data',3,1),(16,'startservice',1,'开启服务',3,1),(17,'permission',1,'权限管理',4,1),(18,'updatepwd',1,'更改密码',4,1),(19,'addaccount',1,'添加用户',4,1);
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$24000$Ao8VkYxfmZLQ$0tTHWpe3a/RPBg+V4AD53BoOG2q8Mvps6tdxcMwz/lw=','2017-05-31 11:30:42.453491',1,'root','','','qyshan_ok@126.com',1,1,'2017-03-23 14:26:29.049481'),(2,'pbkdf2_sha256$24000$ol0WxJD7xU4H$YNl1zRZLEpI7g9UmPiDx+zzVUhhTy3/tH/0NPQHKudw=','2017-05-19 16:15:58.741590',1,'zhujiangtao','','','',1,1,'2017-04-05 16:48:17.488604'),(5,'pbkdf2_sha256$24000$fAtzTB0lDPFP$wqqpWbHi3KAoQA4COQ0VVeQN7zjcCiprZkZqlXjqr30=','2017-05-18 13:36:39.657422',1,'test','','','123@test.com',1,1,'2017-05-09 17:40:55.366661'),(6,'pbkdf2_sha256$24000$9ijeUwv9jjNQ$vFKmrBIiKsPvzCN2gdEQraWKi4YC8UsEOYk5DuaR/mg=','2017-05-31 11:56:44.755678',1,'wangfuhou','','','123@qq.com',1,1,'2017-05-11 12:31:51.842010');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_perm_permission_id_1fbb5f2c_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_user_perm_permission_id_1fbb5f2c_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
INSERT INTO `auth_user_user_permissions` VALUES (99,1,1),(100,1,2),(101,1,3),(102,1,4),(103,1,5),(104,1,6),(105,1,7),(106,1,9),(107,1,10),(108,1,11),(109,1,12),(110,1,13),(111,1,14),(112,1,15),(113,1,16),(114,1,17),(115,1,18),(116,1,19),(117,2,1),(118,2,2),(119,2,3),(120,2,4),(121,2,5),(122,2,6),(123,2,7),(124,2,9),(125,2,10),(126,2,11),(127,2,12),(128,2,13),(129,2,14),(130,2,15),(131,2,16),(132,2,17),(133,2,18),(134,2,19),(84,6,1),(85,6,2),(86,6,3),(87,6,4),(88,6,5),(89,6,6),(90,6,9),(91,6,10),(92,6,11),(93,6,12),(94,6,13),(95,6,14),(96,6,15),(97,6,16),(98,6,18);
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin__content_type_id_c4bce8eb_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin__content_type_id_c4bce8eb_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'auth','user');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (16,'contenttypes','0001_initial','2017-04-10 18:27:26.247577'),(17,'auth','0001_initial','2017-04-10 18:27:26.289050'),(18,'admin','0001_initial','2017-04-10 18:27:26.333779'),(19,'admin','0002_logentry_remove_auto_add','2017-04-10 18:27:26.422781');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('0nrrsvit9ltns8ye0u2vl6i6qrwbt6mb','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-06-01 13:39:32.459350'),('231afd0wea3gro8pvwdbhlc1ioyiyd1p','NTYwZWZiZTZhMjE0ZjFjYWNhNDQ3OTdhNGM2ZDNhNDA2YWM2YjNlNzp7Il9hdXRoX3VzZXJfaGFzaCI6IjYzNDNlOGMxYzk2ZTE2NTZmZTUxMWJhZTU0N2RkNDcwMGJmYjFjNmQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2017-05-26 16:36:04.999889'),('29l0m0tfv77fs4qd8c25qhu8cyvgb9il','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-06-05 17:56:21.541088'),('86oil01kz0fqnwow7umqoaup3as0mvtm','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-05-29 09:17:11.382161'),('asauqfwb313jkvhhkm4fddndoyfih0rq','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-06-06 13:30:04.484456'),('cpxlo2pbk58wsdcarwfzpdcahkax5p9p','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-06-14 11:30:42.465855'),('dfpk2tmy8rxze0x9bepx2fpcl5l1vfks','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-05-19 15:34:12.767944'),('gmmdfp0x3idmuvx3vzols40gy3x0x4ma','NjA5ZGI5ZTJiNjcyOTY4NGEzNzk2MzViZmZiMGE4OTZlOGJlNjQ1Mjp7Il9hdXRoX3VzZXJfaGFzaCI6IjZmYWVhODg4MTdkNTZmNjQ1OTA1YWRkYzdkYTQ2Mjk3ODE3MjUxMTciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=','2017-06-14 11:56:44.759051'),('htzv7q25t4ul8o1xc94o9rw3tibdveev','NTYwZWZiZTZhMjE0ZjFjYWNhNDQ3OTdhNGM2ZDNhNDA2YWM2YjNlNzp7Il9hdXRoX3VzZXJfaGFzaCI6IjYzNDNlOGMxYzk2ZTE2NTZmZTUxMWJhZTU0N2RkNDcwMGJmYjFjNmQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2017-06-02 15:55:57.761007'),('kxx9m5tc4dekset1xd2gi5j895i0u9ly','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-05-26 10:07:20.330297'),('o42kdpxp83w093e5zh693667tgjvpcio','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-06-02 16:33:42.975891'),('obnrrjudatszbpofd04mmtgtb5l81rzp','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-06-08 12:57:41.668487'),('oh9cs8j3ztc940okqqslidsz0cqe0kgc','NTYwZWZiZTZhMjE0ZjFjYWNhNDQ3OTdhNGM2ZDNhNDA2YWM2YjNlNzp7Il9hdXRoX3VzZXJfaGFzaCI6IjYzNDNlOGMxYzk2ZTE2NTZmZTUxMWJhZTU0N2RkNDcwMGJmYjFjNmQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2017-05-31 16:25:26.049245'),('reg1tbui3vrnuig9nllfs64pgvok0bkx','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-05-27 14:13:12.737688'),('scb9n54k0bghhfh3sd9uqkacq0r3ov1m','NTYwZWZiZTZhMjE0ZjFjYWNhNDQ3OTdhNGM2ZDNhNDA2YWM2YjNlNzp7Il9hdXRoX3VzZXJfaGFzaCI6IjYzNDNlOGMxYzk2ZTE2NTZmZTUxMWJhZTU0N2RkNDcwMGJmYjFjNmQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2017-06-02 16:15:58.751838'),('spnarzrndwmqs30nj0pmwc7b8ngod6m7','NjA5ZGI5ZTJiNjcyOTY4NGEzNzk2MzViZmZiMGE4OTZlOGJlNjQ1Mjp7Il9hdXRoX3VzZXJfaGFzaCI6IjZmYWVhODg4MTdkNTZmNjQ1OTA1YWRkYzdkYTQ2Mjk3ODE3MjUxMTciLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiI2In0=','2017-05-25 12:34:43.477329'),('tvc7bmmmfzkww35tpartnlq2e6dlqtdg','ZGFhMmNlN2JlZjhkNzkxNWQ4MGJiOWE2NGE3ODQxNDJhMGEyZmYxYjp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2017-06-02 13:53:31.907578'),('vyd34wfsfk1iknowfsa02p5knoze2cej','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-06-05 10:36:08.025622'),('yu95u7opj4asrubt8pk76z80laj5kjpt','NTU2ODk0NDNiZjZjNTJlNmU3Y2RmY2I0YTdjNjU4ZGNlYjQ2NmJhNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjM0YmMyZGUwN2M5MjQ5NThkZDBjMmE2ODM4YTE4NTllNzZjZmRiZDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2017-05-25 12:33:06.543015');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-06-06 15:34:24
