#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
删除已合game
'''
import baseFun
import multiprocessing

def remove(user,ip,sid,val):
    baseFun.writelog(user,'&&')
    script = 'cd /data/pythonscript;./removeGame.py "%s"'%(val)
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg'])
    #移除成功，更改状态
    if(msg['status'] == 200):
        from fengshen.models import updateIsRemoveStatus
        updateIsRemoveStatus(sid)


def removegame(user,iplist):
    baseFun.writelog(user,'&&')
    pool = multiprocessing.Pool(processes=len(iplist))
    for key,val in iplist.items():
        pool.apply_async(remove, (user,val['inIp'],key,val))
    pool.close()
    pool.join()

    baseFun.writelog(user,'[32m game remove finished[0m')

