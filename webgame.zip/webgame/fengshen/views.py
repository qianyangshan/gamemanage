#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
import os
import sys
reload(sys)
sys.setdefaultencoding('utf8')
sys.path.append('fengshen/api')
from permission import permission_required
from django.conf.urls import url
from django.contrib import admin
from webgame.settings import gamewebvar
from fengshen.models import getAllplatform
from fengshen.models import userAllPermission
from django.shortcuts import render, render_to_response
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login as auth_login, logout
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse


#声明全局字典
data = {}
data['error'] = ''
data['allowinstallnum'] = gamewebvar['allowInstallNum']

# 登陆
def login(request):
    msg = []
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if(user is not None):
            if user.is_active:
                auth_login(request,user)
                return HttpResponseRedirect('/main/')
            else:
                msg.append("disabled account")
        else:
            msg.append("invalid login")    
        return render_to_response('Login.html', {'errors': msg})    
    return render(request,'Login.html',data)
    


#新服配服
@login_required
@permission_required
def creategame(request):

    data['view'] = 'CreateGame.html'
    data['active'] = 'creategame'
    #获取平台
    data['pflist'] = getAllplatform()
    #用户拥有的权限
    data['userpermission'] = userAllPermission(request.user)
    return render(request,'Index.html',data)



#老服配服
@login_required
@permission_required
def creategameagain(request):

    #初始化变量
    data['view'] = 'CreateGameAgain.html'
    data['active'] = 'creategameagain'
    #获取平台
    data['pflist'] = getAllplatform()

    from fengshen.models import findAllowinstallIp
    if (request.method == 'POST'):
        platform = request.POST.get('platform','')
        installnum = request.POST.get('installnum',0)
        inip = request.POST.get('inip','')
        # 查找可用的机器
        if(platform != '' and installnum != ''):
            server = findAllowinstallIp(platform,installnum,inip)
            total = gamewebvar['allowInstallNum'] * len(server)
            data['msg'],inip, used = '', '', 0
            for key,num in server.items():
                used += num
                data['msg'] += '%s: 已配 <strong>%s</strong> 个服 '%(key,num)
            restnums = total - used
            data['msg'] += "剩余<strong> %s </strong>空位 需安装<strong> %s </strong>个服"%(restnums,installnum)
            data['restnums'] = int(restnums)
            data['installnum'] = int(installnum)
            data['inip'] = inip
            data['platform'] = platform
        else:
            data['error'] = '搜索条件不足,请确认后在试.'
            return render_to_response('Index.html', data)

    #用户拥有的权限
    data['userpermission'] = userAllPermission(request.user)
    data['error'] = ''
    return render(request,'Index.html',data)




@login_required
@permission_required
def createcross(request):
    data['view'] = 'CreateCross.html'
    data['active'] = 'createcross'
    #获取平台
    data['pflist'] = getAllplatform()

    if (request.method == 'POST'):
        platform = request.POST.get('platform','')
        inip = request.POST.get('inip','')
        subtype = request.POST.get('subtype',0)
        installnum = request.POST.get('installnum',0)
        if(platform and inip and int(subtype) > 0 and int(installnum) > 0):
            from fengshen.models import gameAndCrossInstallNums
            used = gameAndCrossInstallNums(inip)

            #新机器
            if(int(used) < 1):
                data['error'] = '新机器,请先添加game后在试..'
                return render_to_response('Index.html', data)

            #机器使用情况
            restnums = gamewebvar['allowInstallNum'] - used
            msg = '%s: 已配 <strong>%s</strong> 个服 '%(inip,used)
            msg += "剩余<strong> %s </strong>空位 需安装<strong> %s </strong>个跨服"%(restnums,installnum)
            data['msg'] = msg
            data['installnum'] = int(installnum)
            data['restnums'] = int(restnums)
            data['platform'] = platform
            data['inip'] = inip
            data['subtype'] = subtype
        else:
            data['error'] = '搜索条件不足,请确认后在试.'
            return render_to_response('Index.html', data)

    data['userpermission'] = userAllPermission(request.user)
    data['error'] = ''
    return render(request,'Index.html',data)



#删除已合并的game
@login_required
@permission_required
def removegame(request):
    data['view'] = 'RemoveGame.html'
    data['active'] = 'removegame'
    from fengshen.models import findMergeGameId
    result = findMergeGameId()
    data['mergegamenum'] = len(result)

    data['userpermission'] = userAllPermission(request.user)
    return render(request,'Index.html',data)


#更新第一步 分发文件
@login_required
@permission_required
def uploadfile(request):
    data['view'] = 'UpdateUploadFile.html'
    data['active'] = 'uploadfile'
    #获取平台
    data['pflist'] = getAllplatform()
    
    data['updatetarip'] = gamewebvar['tarServer']
    updatefile = []
    for root, dir, files in os.walk('/data/lastversion'):
        for file in files:     
            updatefile.append(file)
    data['updatefile'] = updatefile

    data['userpermission'] = userAllPermission(request.user)
    return render_to_response('Index.html', data)


#更新第二步 停止服务
@login_required
@permission_required
def stopservice(request):
    data['view'] = 'UpdateStopService.html'
    data['active'] = 'stopservice'

    data['userpermission'] = userAllPermission(request.user)
    return render_to_response('Index.html', data)


#更新第三步 更新game
@login_required
@permission_required
def updategame(request):
    data['view'] = 'UpdateGame.html'
    data['active'] = 'updategame'

    data['userpermission'] = userAllPermission(request.user)
    return render_to_response('Index.html', data)


#更新第四步 更新cross
@login_required
@permission_required
def updatecross(request):
    data['view'] = 'UpdateCross.html'
    data['active'] = 'updatecross'

    data['userpermission'] = userAllPermission(request.user)
    return render_to_response('Index.html', data)


#更新第五步 更新data
@login_required
@permission_required
def updatedata(request):
    data['view'] = 'UpdateData.html'
    data['active'] = 'updatedata'

    data['userpermission'] = userAllPermission(request.user)
    return render_to_response('Index.html', data)


#更新第六步 开启服务
@login_required
@permission_required
def startservice(request):
    data['view'] = 'UpdateStartService.html'
    data['active'] = 'startservice'

    data['userpermission'] = userAllPermission(request.user)
    return render_to_response('Index.html', data)


#迁移game
@login_required
@permission_required
def transfergame(request):
    data['view'] = 'transferGame.html'
    data['active'] = 'transfergame'
    #获取平台
    data['pflist'] = getAllplatform()

    if request.method == 'POST':
        platform = request.POST.get('platform','')
        pid = request.POST.get('pid','')
        sourceip = request.POST.get('sourceip','')
        targetip = request.POST.get('targetip','')
        if((platform and pid) or sourceip):
            from fengshen.models import findTransferGameinfo
            data['transferinfo'] = findTransferGameinfo(platform,pid,sourceip,targetip)
        else:
            data['error'] = '搜索条件不满足，请确认后再试'
            return render_to_response('Index.html',data)
    
    data['userpermission'] = userAllPermission(request.user)
    data['error'] = ''
    return render(request,'Index.html',data) 


#cross迁移
@login_required
@permission_required
def transfercross(request):
    data['view'] = 'transferCross.html'
    data['active'] = 'transfercross'
    #获取平台
    pflist = getAllplatform()
    data['pflist'] = pflist
    if request.method == 'POST':
        platform = request.POST.get('platform','')
        cid = request.POST.get('cid',0)
        sourceip = request.POST.get('sourceip','')
        targetip = request.POST.get('targetip','')
        if((platform and cid) or sourceip):
            from fengshen.models import findTransferCrossinfo
            data['transferinfo'] = findTransferCrossinfo(platform,cid,sourceip,targetip)
            data['platform'] = platform
        else:
            data['error'] = '搜索条件不满足，请确认后再试'
            return render_to_response('Index.html',data)   
  
    data['userpermission'] = userAllPermission(request.user)
    data['error'] = ''
    return render(request,'Index.html',data)



#game进程管理
@login_required
@permission_required
def gameprocess(request):
    data['view'] = 'gameProcess.html'
    data['active'] = 'gameprocess'
    #获取平台
    data['pflist'] = getAllplatform()
    if request.method == 'POST':
        platform = request.POST.get('platform','')
        pid  = request.POST.get('pid','')
        inip = request.POST.get('inip','')
        from fengshen.models import findGameProcessInfo
        data['serverlist'] = findGameProcessInfo(platform,pid,inip)
        data['pid'] = pid
        data['inip'] = inip
        data['platform'] = platform

    data['userpermission'] = userAllPermission(request.user)        
    return render(request,'Index.html',data)



#game进程管理
@login_required
@permission_required
def crossprocess(request):
    data['view'] = 'crossProcess.html'
    data['active'] = 'crossprocess'
    #获取平台
    data['pflist'] = getAllplatform()
    if request.method == 'POST':
        platform = request.POST.get('platform','')
        cid  = request.POST.get('cid','')
        inip = request.POST.get('inip','')
        from fengshen.models import findCrossProcessInfo
        data['serverlist'] = findCrossProcessInfo(platform,cid,inip)
        data['cid'] = cid
        data['inip'] = inip
        data['platform'] = platform

    data['userpermission'] = userAllPermission(request.user)
    return render(request,'Index.html',data)
   


#执行客户端脚本
@login_required
def execscript(request):
    if request.method == 'POST':
        mod = request.POST.get('mod','')
        platform = request.POST.get('platform','')
        inip = request.POST.get('inip','')
        #老服配服
        if(mod == 'creategameagain'):
            from fengshen.models import findAllowinstallIp,createGameSql2
            installnum = request.POST.get('installnum',0)
            #查找可用机器
            server = findAllowinstallIp(platform,installnum,inip)
            if(not server):
                return HttpResponse('The machine is full')
            #生成sql
            serverlist = list(server.keys())
            result = createGameSql2(platform,installnum,serverlist)
            #安装
            from installGame import install
            install(request.user,result)
            return HttpResponse()
       
        #添加新服
        elif(mod == 'creategame'):
            from fengshen.models import createGameSql,isNewIp
            installnum = request.POST.get('installnum',0)
            iplist = inip.split(',')
            for ip in iplist:
                if(not isNewIp(ip)):
                    return HttpResponse('当前机器已配置区服,请使用老服配服')
            
            result = createGameSql(platform,iplist,installnum)
            #安装
            from installGame import install
            #install(request.user,result)
            return HttpResponse()

        #跨服配置
        elif(mod == 'createcross'):
            installnum = request.POST.get('installnum',0)
            subtype = request.POST.get('subtype',0)
            from fengshen.models import createCrossSql,gameAndCrossInstallNums
            used = gameAndCrossInstallNums(inip)
            restnums = gamewebvar['allowInstallNum'] - int(used)
            if(int(installnum) > restnums or restnums < 1):
                return HttpResponse('机器不可用..')
            #生成sql 
            result = createCrossSql(platform,inip,installnum,subtype)
            #安装
            from installCross import install
            install(request.user,result)
            return HttpResponse()

        #更新第一步
        elif(mod == 'pullnewtar'):
            from tarForUpdate import tarFile
            msg = tarFile()
            return HttpResponse(msg['status'])

        # 更新第一步 分发文件
        elif(mod == 'uploadfile'):
            from fengshen.models import findUpdateServer
            result = findUpdateServer()
            from updateUploadFile import upload
            upload(request.user,result)
            return HttpResponse()

        # 更新第二步 停服
        elif(mod == 'stopservice'):
            from fengshen.models import findGameSid,findCrossId

            #停game
            result = findGameSid()
            from updateStopGame import stopGame
            stopGame(request.user,result)

            #停cross
            result = findCrossId() 
            from updateStopCross import stopCross
            result = findCrossId() 
            stopCross(request.user,result)
            return HttpResponse()

        #更新game
        elif(mod == 'updategame'):
            from fengshen.models import findGameSid
            result = findGameSid()
            from updateGame import updateFile
            updateFile(request.user,result)
            return HttpResponse()

        #更新cross
        elif(mod == 'updatecross'):
            from fengshen.models import findCrossId
            result = findCrossId()
            from updateCross import updateFile
            updateFile(request.user,result)
            return HttpResponse()

        #更新data
        elif(mod == 'updatedata'):
            from fengshen.models import findUpdateServer
            result = findUpdateServer()
            from updateData import updateFile
            updateFile(request.user,result)
            return HttpResponse()

        #开启服务        
        elif(mod == 'startservice'):
            from fengshen.models import findGameSid,findCrossId

            #开启game
            result = findGameSid()
            from updateStartGame import startGame
            startGame(request.user,result)

            #开启cross
            result = findCrossId()
            from updateStartCross import startCross
            result = findCrossId()
            startCross(request.user,result)
            return HttpResponse()
       
         #删除合服
        elif(mod == 'removemergegame'):
            from fengshen.models import findMergeGameId
            result = findMergeGameId()
            from removeMergeGame import removegame
            removegame(request.user,result)
            return HttpResponse()
        
        #迁移game`
        elif(mod == 'transfergame'):
            sid = request.POST.get('sourcesid','')
            targetip = request.POST.get('targetip','')
            from fengshen.models import findMysqlAndRedisInfo,createTransferGame
            result = findMysqlAndRedisInfo(sid,targetip)
            #mysql,redis数据从迁移目标IP
            from transferGame import mysqlAndRedis,createGame
            mysqlAndRedis(request.user,result)
            #生成game
            gameinfo = createTransferGame(result)
            createGame(request.user,gameinfo)
            return HttpResponse()
 
        #迁移cross
        elif(mod == 'transfercross'):
            cid = request.POST.get('sourcecid','')            
            targetip = request.POST.get('targetip','')
            from fengshen.models import createTransferCross
            result = createTransferCross(cid,targetip,platform)
            from transferCross import createCross
            createCross(request.user,result)
            return HttpResponse()            

        #开启game
        elif(mod == 'gamestart'):
            pid  = request.POST.get('pid','')
            from fengshen.models import findSidForGameProcess
            result = findSidForGameProcess(platform,pid,inip)
            from gameServiceStart import gameStart
            gameStart(request.user,result)
            return HttpResponse()

        #停服game
        elif(mod == 'gamestop'):
            pid  = request.POST.get('pid','')
            from fengshen.models import findSidForGameProcess
            result = findSidForGameProcess(platform,pid,inip)
            from gameServiceStop import gameStop
            gameStop(request.user,result)
            return HttpResponse()

        #开启cross
        elif(mod == 'crossstart'):
            cid =  request.POST.get('cid','')
            from fengshen.models import findCidForCrossProcess
            result = findCidForCrossProcess(platform,cid,inip)
            from crossServiceStart import crossStart
            crossStart(request.user,result)
            return HttpResponse()

        #停服cross
        elif(mod == 'crossstop'):
            cid =  request.POST.get('cid','')
            from fengshen.models import findCidForCrossProcess
            result = findCidForCrossProcess(platform,cid,inip)
            from crossServiceStop import crossStop
            crossStop(request.user,result)
            return HttpResponse()

        #检查game,cross状态
        elif(mod == 'servicestatus'):
            service = request.POST.get('service','')
            from fengshen.models import getServiceStatus 
            ret = getServiceStatus(service)
            # {u'4': 2, u'5': 0}
            return JsonResponse(ret)
        elif(mod == 'initserver'):
            from initServer import initService
            pwd = request.POST.get('pwd','')
            iplist = inip.split(',')
            initService(request.user,pwd,iplist)
            return HttpResponse()
        #脚本日志
        elif(mod == 'showlog'):
            from fengshen.models import scriptLog
            log = scriptLog(request.user)
            return HttpResponse(log)

    return HttpResponse('mod not exists')
    

#用户管理
@login_required
def account(request):
    
    data['view'] = 'Account.html'
    data['active'] = 'account'
    data['uid'] = request.user.id

    op = request.GET.get('op')
    uid = request.GET.get('uid')
    if(op == 'delaccount' and int(uid) > 0):
        from fengshen.models import deleteAccount
        deleteAccount(uid)

    from fengshen.models import getAllUser
    data['accoutlist'] = getAllUser()

    data['userpermission'] = userAllPermission(request.user)
    return render(request,'Index.html',data)
    


#权限管理
@login_required
@permission_required
def permission(request):
    data['view'] = 'AccountPermission.html'
    data['active'] = 'account'
    uname = request.GET.get('uname','root')
    uid = request.GET.get('uid',1)
    data['uname'] = uname
    data['uid'] = uid
    if request.method == 'POST':
        menuid = request.POST.getlist('menuid[]',[])
        from fengshen.models import updateUserPermission
        updateUserPermission(uname,uid,menuid)
        return HttpResponseRedirect("/permission/?uname=%s&uid=%s"%(uname,uid))
    
    data['userpermission'] = userAllPermission(uname) 
    return render(request,'Index.html',data)



#添加用户
@login_required
@permission_required
def addaccount(request):

    data['view'] = 'AccountAdd.html'
    data['active'] = 'account'
    if request.method == 'POST':
        uname = request.POST.get('username','')
        password = request.POST.get('password','')
        from django.contrib.auth.models import User
        User.objects.create_superuser(uname,'123@test.com',password)
        return HttpResponseRedirect('/account/')

    data['uid'] = request.user.id
    data['userpermission'] = userAllPermission(request.user)
    return render(request,'Index.html',data)
    

#修改密码
def updatepwd(request):
    data['view'] = 'AccountUpdatePwd.html'
    data['active'] = 'account'
    uname = request.GET.get('uname','')
    uid = request.GET.get('uid',1)
    data['uname'] = uname
    data['uid'] = uid
    if request.method == 'POST':
        from django.contrib.auth.models import User
        user =User.objects.get(username=uname)
        password = request.POST.get('password','')
        user.set_password(password)
        user.save()
        return HttpResponseRedirect('/account/')
        
    data['userpermission'] = userAllPermission(request.user)
    return render(request,'Index.html',data)



# 管理后台首页
@login_required
def main(request):
    from fengshen.models import serviceRunInfo
    data['serviceruninfo'] = serviceRunInfo()
    data['view'] = 'Main.html'
    data['active'] = 'main'
    data['userpermission'] = userAllPermission(request.user)
    return render(request,'Index.html',data)
    

#服务器初始化
@login_required
def initserver(request):
    data['view'] = 'InitServer.html'
    data['active'] = 'initserver'
    data['userpermission'] = userAllPermission(request.user)
    return render(request,'Index.html',data)
    
    
# 登出  
def loginout(request):
    logout(request)
    return render(request,'Login.html',data)
