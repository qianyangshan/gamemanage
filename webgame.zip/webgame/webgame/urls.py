# -*- coding: utf-8 -*-
"""webgame URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url,include
from django.contrib import admin
from fengshen.views import *

urlpatterns = [
    url(r'^main/$',main),
    url(r'^initserver/$',initserver),
    url(r'^updatepwd/$',updatepwd),
    url(r'^addaccount/$',addaccount),
    url(r'^permission/',permission),
    url(r'^gameprocess/$',gameprocess),
    url(r'^crossprocess/$',crossprocess),
    url(r'^transfergame/$',transfergame),
    url(r'^transfercross/$',transfercross),
    url(r'^removegame/$',removegame),
    url(r'^uploadfile/$',uploadfile),
    url(r'^stopservice/$',stopservice),
    url(r'^updategame/$',updategame),
    url(r'^updatecross/$',updatecross),
    url(r'^updatedata/$',updatedata),
    url(r'^startservice/$',startservice),
    url(r'^creategame/$',creategame),
    url(r'^creategameagain/$',creategameagain),
    url(r'^createcross/$',createcross),
    url(r'^execscript/$',execscript),
    url(r'^account/$',account),
    url(r'^account/addaccount/$',addaccount),
    url(r'^loginout/$',loginout),
    url(r'',login),
]
