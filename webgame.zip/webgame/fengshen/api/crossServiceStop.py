#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
开启cross
'''
import baseFun
import multiprocessing

def stop(user,ip,cid):
    print user,ip,cid
    '''
    baseFun.writelog(user,'&&')
    script = 'cd /data/pythonscript;./serviceCrossStop.py %s'%(sid)
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg']) 
    '''
    

def crossStop(user,iplist):
    baseFun.writelog(user,'&&')
    pool = multiprocessing.Pool(processes=len(iplist))
    for inip,cid in iplist.items():
        pool.apply_async(stop, (user,inip,cid))
    pool.close()
    pool.join()
