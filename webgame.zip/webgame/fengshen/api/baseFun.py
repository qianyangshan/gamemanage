#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
安装game
'''
import sys
import logging
import paramiko
import commands
import traceback
from webgame.settings import BASE_DIR
from webgame.settings import gamewebvar

#执行远程脚本，命令
def sshCmd(ip,cmd):
    ssh = paramiko.SSHClient()
    paramiko.util.log_to_file('ssh.log')
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(ip, gamewebvar['sshPort'], 'root',gamewebvar['sshPwd'])
        stdin, stdout, stderr = ssh.exec_command(cmd)
        error = stderr.read()
        if(error):
           return str({"status": 500,"msg":error})
        return stdout.read()
    except :
        return str({"status": 500,"msg": "can not connect %s"%(ip)})


##上传初始化程序文件压缩包
def uploadFileForInitServer(pwd,ip):
    try:
        #上传文件
        paramiko.util.log_to_file('ssh.log')
        ssh = paramiko.Transport((ip,21003))
        ssh.connect(username = 'root', password = pwd)
        sftp = paramiko.SFTPClient.from_transport(ssh)
        sftp.put(gamewebvar['initTarFile'],gamewebvar['initTarFileUploadPath'])
        ssh.close()
        #解压
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(ip, 21003, 'root',pwd)
        script = 'tar zxf %s'%(gamewebvar['initTarFileUploadPath'])
        stdin,stdout,stderr = ssh.exec_command(script)
        ssh.close()
        return str({"status":200, "msg": "%s upload success"%(ip)})
    except:
        return str({"status": 500,"msg": "can not connect %s"%(ip)})


'''
记录脚本日志信息
'''
def writelog(user,msg):
    import time
    datetime = time.strftime('%Y-%m-%d %X',time.localtime())
    logfile = BASE_DIR + '/logs/%s.log'%(user)
    fobj = open(logfile,'a')
    msgstr = datetime + ' ' + msg + '\n'
    fobj.write(msgstr)
    fobj.close()
