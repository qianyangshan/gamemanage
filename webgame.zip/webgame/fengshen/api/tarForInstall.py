#!/usr/bin/python2.6
# -*- coding: utf-8 -*-
# 打包安装文件
# author qyshan
# date 2016-3-22

import os
import sys
import time
import tarfile
import commands

#程序文件根目录
rootdir = '/data/server'

#压缩包放置目录
tardir = '/data/lastversion'
if(not os.path.exists(tardir)):
    os.makedirs(tardir)

commands.getstatusoutput('rm -rf %s/*'%(tardir))
#打包
def tarFile():
    tarlist = ['game','cross','logger','data','sql']
    datestr = time.strftime('%Y-%m-%d-%H%M',time.localtime())
    os.chdir(rootdir)
    for tarname in tarlist:
        if(tarname == 'sql'):
            (s,o) = commands.getstatusoutput('mysqldump -uroot %s -dR >%s/game_%s.sql'%('fengshen_1',tardir,datestr))
            if(s !=0):
                return {"status": 500,"msg": "[31mtarfile was fail[0m"}
            continue

        tarfname = ('%s/%s_%s.tar.gz'%(tardir,tarname,datestr))
        tar = tarfile.open(tarfname, "w:gz")
        if(tarname == 'data'):
            os.chdir(rootdir + '/data')
        for root, dir, files in os.walk(tarname):
            for file in files:
                if('.log' in file):
                    continue
                fullpath = os.path.join(root, file)
                tar.add(fullpath)
        tar.close()
    return {"status": 200,"msg": "tarfile success"}
