#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
更新第五步 更新data
'''
import baseFun
import multiprocessing

def update(user,ip):
    baseFun.writelog(user,'&&')
    script = 'cd /data/pythonscript;./updateData.py'
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg'])
    

def updateFile(user,iplist):
    baseFun.writelog(user,'&&')
    pool = multiprocessing.Pool(processes=len(iplist))
    for key,inip in iplist.items():
        pool.apply_async(update, (user,inip))
    pool.close()
    pool.join()

    baseFun.writelog(user,'[32m data update finished[0m')

