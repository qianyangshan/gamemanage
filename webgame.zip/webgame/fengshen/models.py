# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import connection
from django.contrib import admin
from webgame.settings import gamewebvar
import os

# 建立连接
cursor = connection.cursor()


#获取平台
def getAllplatform():
    sql = 'SELECT DISTINCT platform FROM Serverinfo'
    cursor.execute(sql)
    return cursor.fetchall()
    
        
# 管理员列表
def getAllUser():
    results = {}
    sql = 'SELECT id,last_login,is_superuser,username,email,is_active FROM auth_user'
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    if(None not in fetchall):
        for index in range(len(fetchall)):
            createTwoDict(results,index,'id',fetchall[index][0])
            createTwoDict(results,index,'last_login',fetchall[index][1])
            createTwoDict(results,index,'is_superuser',fetchall[index][2])
            createTwoDict(results,index,'username',fetchall[index][3])
            createTwoDict(results,index,'email',fetchall[index][4])
            createTwoDict(results,index,'is_active',fetchall[index][5])
    return results
    
    

# 创建二维字典
def createTwoDict(thedict, key_a, key_b, val): 
    if key_a in thedict:
        thedict[key_a].update({key_b: val})
    else:
        thedict.update({key_a:{key_b: val}})
        

#创建游戏对应的域名
def createHostname():
    sql = 'SELECT host_name FROM Serverinfo ORDER BY host_name DESC LIMIT 1'
    cursor.execute(sql)
    row = cursor.fetchone()
    if(row):
        domain_prefix = row[0].split('.')[0]
        newdomain = 's%s.fengshen.lingyunetwork.com'%(int(domain_prefix[1:]) + 1)
        return newdomain
    return 's1.fengshen.lingyunetwork.com'


#外网Ip
def getOutip(inip):
    from baseFun import sshCmd
    cmd = "ifconfig | grep '183.131' | cut -d: -f2 | awk '{ print $1}'"
    ret = sshCmd(inip,cmd)
    if(ret == ''):
        cmd = "ifconfig | grep '122.226' | cut -d: -f2 | awk '{ print $1}'"
        ret = sshCmd(inip,cmd)
    if(type(ret) is dict):
        return ''
    return ret.replace('\n','')


#是否新机器
def isNewIp(inip):
    sql = "SELECT server_id FROM Serverinfo WHERE in_ip = '%s'"%(inip)
    cursor.execute(sql)
    row = cursor.fetchone()
    if(row):
        return False
    return True


#新服配置 生成sql
def createGameSql(platform,iplist,installnum):
    import time
    datetime = time.strftime('%Y-%m-%d %X',time.localtime())
    sid = getMaxSid()
    pid = getMaxPlatformId(platform)
    insid = 0
    installcache = {}
    y = 0
    filterinsid = {}
    hostnamedict = {}
    for i in range(int(installnum)):
        sid += 1
        pid += 1

        if(filterinsid.has_key(iplist[y])):
            insid = getMaxInstallId(iplist[y],filterinsid[iplist[y]])
        else:
            insid = getMaxInstallId(iplist[y])        
        inip = iplist[y]
            
        outip = getOutip(inip)

        if (hostnamedict.has_key(iplist[y])):
            hostname = hostnamedict[iplist[y]] 
        else:
            hostname = createHostname()

        sql = "INSERT INTO Serverinfo(server_id,platform_id,install_id,host_name,platform,\
               in_ip,out_ip,open_time)VALUES('%s','%s','%s','%s','%s','%s','%s','%s')"%\
               (sid,pid,insid,hostname,platform,inip,outip,datetime)
        cursor.execute(sql)

        #安装game参数
        createTwoDict(installcache,sid,'sid',sid)
        createTwoDict(installcache,sid,'inSid',insid) 
        createTwoDict(installcache,sid,'platform',platform)
        createTwoDict(installcache,sid,'pid',pid)
        createTwoDict(installcache,sid,'inIp',inip)
        createTwoDict(installcache,sid,'outIp',outip)
        createTwoDict(installcache,sid,'hostName',hostname)
        createTwoDict(installcache,sid,'redisPort',gamewebvar['redisPort'] + insid)
        createTwoDict(installcache,sid,'dbUser',gamewebvar['dbUser'])
        createTwoDict(installcache,sid,'dbPwd',gamewebvar['dbPwd'])
        createTwoDict(installcache,sid,'dbName','%s%s'%(gamewebvar['dbNamePre'],sid))
        createTwoDict(installcache,sid,'innerPort',gamewebvar['innerPort'] + insid)
        createTwoDict(installcache,sid,'tcpPort',gamewebvar['tcpPort'] + insid)
        createTwoDict(installcache,sid,'webPort',gamewebvar['webPort'] + insid)
        createTwoDict(installcache,sid,'redisGlobalIp',gamewebvar['globalRedis'])

        if(filterinsid.has_key(iplist[y])):
            filterinsid[iplist[y]] += str(insid) + ','
        else:
            filterinsid[iplist[y]] = str(insid) + ','
  
        if(not hostnamedict.has_key(iplist[y])):
            hostnamedict[iplist[y]] = hostname

        y += 1
        if(y == len(iplist)):
            y = 0

    return installcache


            
        
#查找有空位的机器
def findAllowinstallIp(platform,installnum,inip):
    from collections import Counter
    # 找出机器中game点用数
    sql = 'SELECT in_ip FROM Serverinfo WHERE is_hf = 0'
    if(inip != ''):
        sql = sql + " AND in_ip = '%s'"%(inip)
    if(platform != ''):
        sql += " AND platform = '%s'"%(platform)
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    serverlist = {}
    gameandcrossnum = {}
    if(None not in fetchall):
        gameinstallnum = Counter(fetchall)
        # cross占用数
        for key,vals in dict(gameinstallnum).items():
            crossinstallnum = crossInstallNum(key[0])
            gameandcrossnum[key[0]] = int(vals) + crossinstallnum
        # 排序占用少的排前面
        sortdict = sorted(gameandcrossnum.items(),key=lambda item:item[1])
        #一个机器最多安装数
        allowinstallnum = gamewebvar['allowInstallNum']
        #找出有空位的机器
        for key,vals in sortdict:
            if(allowinstallnum > vals):
                serverlist[key] = vals

    return serverlist


# 查找机器中cross占用数
def crossInstallNum(inip):
    sql = "SELECT COUNT(cross_id) FROM Crossinfo WHERE in_ip = '%s'"%(inip)
    cursor.execute(sql)
    row = cursor.fetchone()
    if(None not in row):
        return row[0]
    return 0
    



#最大的server_id
def getMaxSid():
    sql = "SELECT MAX(server_id) FROM Serverinfo"
    cursor.execute(sql)
    row = cursor.fetchone()
    if(None not in row):
        return row[0]
    return 0


#平台最大ID
def getMaxPlatformId(platform):
    sql = "SELECT MAX(platform_id) FROM Serverinfo WHERE platform = '%s'"%(platform)
    cursor.execute(sql)
    row = cursor.fetchone()
    if(None not in row):
        return row[0]
    return 0


#game可用空位号
def getMaxInstallId(inip,filterid=0):
    sql = "SELECT install_id FROM Serverinfo WHERE in_ip = '%s' AND is_hf = 0"%(inip)
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    from compiler.ast import flatten
    allowinstallnum = gamewebvar['allowInstallNum']
    if(None not in fetchall):
        for insid in range(1, (allowinstallnum + 1)):
            if(str(insid) in str(filterid).split(',')):
                continue
            if(insid not in flatten(fetchall)):
                return int(insid)
    return 1

# 域名，外网IP
def getDomainOutipSalt(inip):
    sql = "SELECT host_name,out_ip FROM Serverinfo WHERE in_ip = '%s'"%(inip)
    cursor.execute(sql)
    row = cursor.fetchone()
    data = {}
    if(row):
        return {"hostname":row[0],"outip":row[1]}
    return {"hostname":"","outip":""}


#生成game老服sql
def createGameSql2(platform,installnum,iniplist):
    sid = getMaxSid()
    pid = getMaxPlatformId(platform)
    y = 0
    installcache = {}
    for i in range(int(installnum)):
        sid += 1
        pid += 1
        insid = getMaxInstallId(iniplist[y])
        result = getDomainOutipSalt(iniplist[y])
        host_name = result['hostname']
        out_ip = result['outip']
        import time
        datetime = time.strftime('%Y-%m-%d %X',time.localtime())

        sql = "INSERT INTO Serverinfo(server_id,platform_id,install_id,host_name,platform,\
        in_ip,out_ip,open_time)VALUES('%s','%s','%s','%s','%s','%s','%s','%s')"%\
        (sid,pid,insid,host_name,platform,iniplist[y],out_ip,datetime)
        cursor.execute(sql)
        #安装game参数
        createTwoDict(installcache,sid,'sid',sid)
        createTwoDict(installcache,sid,'inSid',insid)
        createTwoDict(installcache,sid,'platform',platform)
        createTwoDict(installcache,sid,'pid',pid)
        createTwoDict(installcache,sid,'inIp',iniplist[y])
        createTwoDict(installcache,sid,'outIp',out_ip)
        createTwoDict(installcache,sid,'hostName',host_name)
        createTwoDict(installcache,sid,'redisPort',gamewebvar['redisPort'] + insid)
        createTwoDict(installcache,sid,'dbUser',gamewebvar['dbUser'])
        createTwoDict(installcache,sid,'dbPwd',gamewebvar['dbPwd'])
        createTwoDict(installcache,sid,'dbName','%s%s'%(gamewebvar['dbNamePre'],sid))
        createTwoDict(installcache,sid,'innerPort',gamewebvar['innerPort'] + insid)
        createTwoDict(installcache,sid,'tcpPort',gamewebvar['tcpPort'] + insid)
        createTwoDict(installcache,sid,'webPort',gamewebvar['webPort'] + insid)
        createTwoDict(installcache,sid,'redisGlobalIp',gamewebvar['globalRedis'])
        #循环分配
        y += 1
        if(len(iniplist) == y):
            y = 0
    return installcache


#查找机器是否有空位安装跨服
def gameAndCrossInstallNums(inip):
    #前面机器上game安装数
    gameinstallnums = 0
    sql = "SELECT COUNT(server_id) FROM Serverinfo WHERE is_hf = 0 AND in_ip = '%s'"%(inip)
    cursor.execute(sql)
    row = cursor.fetchone()
    if(row):
        gameinstallnums = row[0]
    #当前机器上cross安装数
    crossinstallnums = crossInstallNum(inip)
    return (gameinstallnums + crossinstallnums)



#最大crossid
def getMaxCrossId(subtype):
    where = ''
    if(subtype == 3):
        where = 'cross_id < 65000'
    elif(subtype == 4):
        where = 'cross_id > 65000'
    sql = "SELECT MAX(cross_id) FROM Crossinfo WHERE %s"%(where)
    cursor.execute(sql)
    row = cursor.fetchone()
    if(None not in row):
        return row[0]
    return 0


#最大insid
def getCrossMaxInstallId(inip):
    sql = "SELECT install_id FROM Crossinfo WHERE in_ip = '%s'"%(inip)
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    from compiler.ast import flatten
    allowinstallnum = gamewebvar['allowInstallNum']
    if(None not in fetchall):
        for insid in range(1, (allowinstallnum + 1)):
            if(insid not in flatten(fetchall)):
                return insid
    return 1


#跨服outip
def getCrossOutIp(inip):
    sql = "SELECT out_ip FROM Crossinfo WHERE in_ip = '%s'"%(inip)
    cursor.execute(sql)
    row = cursor.fetchone()
    if(None not in row):
        return row[0]
    return ''


#生成cross跨服sql
def createCrossSql(platform,inip,installnum,subtype):
    
    cid = getMaxCrossId(int(subtype))
    insid = getCrossMaxInstallId(inip)
    outip = getCrossOutIp(inip)
    import time
    datetime = time.strftime('%Y-%m-%d %X',time.localtime())
    installdict = {}
    for i in range(int(installnum)):
        cid += 1
        sql = "INSERT INTO Crossinfo(cross_id,install_id,platform,in_ip,out_ip,open_time,subType)VALUES(\
               '%s','%s','%s','%s','%s','%s','%s')"%(cid,insid,platform,inip,outip,datetime,subtype)
        cursor.execute(sql)
        #安装参数
        createTwoDict(installdict,cid,'cid',cid)
        createTwoDict(installdict,cid,'subType',subtype)
        createTwoDict(installdict,cid,'inIp',inip)
        createTwoDict(installdict,cid,'innerPort',gamewebvar['crossInnerPort'] + insid)
        createTwoDict(installdict,cid,'webPort',gamewebvar['crossWebPort'] + insid)
        createTwoDict(installdict,cid,'redisGlobalIp',gamewebvar['globalRedis'])
        createTwoDict(installdict,cid,'platform',platform)
        insid += 1

    return installdict
    


#更新区服数据
def findUpdateServer():
    #game
    sql = 'SELECT DISTINCT in_ip FROM Serverinfo'
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    #cross
    sql = 'SELECT DISTINCT in_ip FROM Crossinfo'
    cursor.execute(sql)
    fetchall2 = cursor.fetchall()
    mergelist = list(set(fetchall + fetchall2))
    iplist = {}
    for i in range(len(mergelist)):
        iplist[i] = mergelist[i][0]
    return iplist 


#找出game区服id
def findGameSid():
    sql = 'SELECT server_id,in_ip FROM Serverinfo WHERE is_hf = 0'
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    sidlist = {}
    for i in fetchall:
        if(sidlist.has_key(i[1])):
            sidlist[i[1]] = '%s,%s'%(sidlist[i[1]],i[0])
        else:
            sidlist[i[1]] = i[0]
    return sidlist
    

#找出cross跨服id
def findCrossId():
    sql = 'SELECT cross_id,in_ip FROM Crossinfo'
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    cidlist = {}
    for i in fetchall:
        if(cidlist.has_key(i[1])):
            cidlist[i[1]] = '%s,%s'%(cidlist[i[1]],i[0])
        else:
            cidlist[i[1]] = i[0]
    return cidlist


#已合game
def findMergeGameId():
    sql = 'SELECT server_id,install_id,in_ip FROM Serverinfo WHERE is_hf = 1 AND is_remove = 0'
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    siddict = {}
    for i in fetchall:
        createTwoDict(siddict,i[0],'sid',i[0])
        createTwoDict(siddict,i[0],'redisPort',gamewebvar['redisPort'] + int(i[1]))
        createTwoDict(siddict,i[0],'dbUser',gamewebvar['dbUser'])
        createTwoDict(siddict,i[0],'inIp',i[2])
        createTwoDict(siddict,i[0],'dbPwd',gamewebvar['dbPwd'])
        createTwoDict(siddict,i[0],'dbName',gamewebvar['dbNamePre'] + str(i[0]))
    return  siddict


#更改isremove状态
def updateIsRemoveStatus(sid):
    sql = "UPDATE Serverinfo SET is_remove = 1 WHERE server_id = %s"%(sid)
    cursor.execute(sql)


#迁移服信息
def findTransferGameinfo(platform,pid,sourceip,targetip):
    sql = "SELECT server_id,in_ip FROM Serverinfo WHERE is_hf = 0"
    if(platform and pid):
        pidlist = ''
        for i in pid.split(','):
            pidlist += "'%s',"%(i)
        sql += " AND platform = '%s' AND platform_id IN(%s)"%(platform,pidlist[:-1])
    if(sourceip):
        sql += " AND in_ip = '%s'"%(sourceip)
    cursor.execute(sql)
    gameinfo = cursor.fetchall()
    #返回信息
    ret = ''
    # 迁移源机器
    iplist = []
    #迁移服id
    sidlist = ''
    for i in gameinfo:
        if(i[1] not in iplist):
            iplist.append(i[1])
        sidlist += '%s,'%(i[0])
        ret += 'game%s '%(i[0])
    ret += '共 <strong id="transfer">%s</strong> 个服迁移 '%(len(gameinfo))

    sql = 'SELECT * FROM Serverinfo WHERE is_hf = 0'
    #指定目标机器,迁移源和目标不能相同
    if(targetip and (targetip not in iplist)):
        sql += ' AND in_ip = "%s"'%(targetip)
        cursor.execute(sql)
        fetchall = cursor.fetchall()
        ret += '%s: 已配 <strong id="used">%s</strong> 个服 '%(targetip,len(fetchall))
        restnums = gamewebvar['allowInstallNum'] - len(fetchall)
        ret += '剩余 <strong id="restnums">%s</strong> 空位 '%(restnums) 
    else:
        # 未指定，优先分配到空位多的机器
        allowinstallip = findAllowinstallIp(platform,20,'')
        #删除和源机器相同的ip
        for i in iplist:
            if(allowinstallip.has_key(i)):
                allowinstallip.pop(i)
                continue

        for key,val in allowinstallip.items():
            targetip += '%s,'%(key)
        #迁移目标服ip
        targetip = targetip[:-1]
        #空位多的机器
        totalused  = 0
        for inip,used in allowinstallip.items():
            ret += '%s: 已配 <strong id="used">%s</strong> 个服 '%(inip,used)
            totalused += used
        restnums = gamewebvar['allowInstallNum']*len(allowinstallip) - totalused
        ret += '剩余 <strong id="restnums">%s</strong> 空位 '%(restnums)

    return {"msg":ret,"transfernum":len(gameinfo),"restnums":int(restnums),"sourcesid":sidlist[:-1],"targetip":targetip} 



#获取insid
def getTransferInsidAndInip(sid):
    sql = "SELECT install_id,in_ip,platform,platform_id,host_name FROM Serverinfo WHERE server_id = '%s'"%(sid)
    cursor.execute(sql)
    row = cursor.fetchone()
    if(row):
        return {"insid":row[0],"inip":row[1],"platform":row[2],"pid":row[3],"hostname":row[4]}
    return {"insid":"","inip":"","platform":"","pid":"","hostname":""}


#迁移game---mysql,redis信息
def findMysqlAndRedisInfo(sid,targetip):
    data = {}
    sidlist = sid.split(',')
    iplist = targetip.split(',')
    y = 0
    #记录iplist中机器已经使用过的install_id
    filterinsid = {}
    for i in sidlist:
        gameinfo = getTransferInsidAndInip(i)
        if(filterinsid.has_key(iplist[y])):
            targetinsid = getMaxInstallId(iplist[y],filterinsid[iplist[y]])
        else:
            targetinsid = getMaxInstallId(iplist[y])

        #生成新服安装信息
        createTwoDict(data,i,'sid',i)
        createTwoDict(data,i,'pid',gameinfo['pid'])
        createTwoDict(data,i,'inip',gameinfo['inip'])
        createTwoDict(data,i,'insid',targetinsid)
        createTwoDict(data,i,'targetip',iplist[y])
        createTwoDict(data,i,'platform',gameinfo['platform'])
        createTwoDict(data,i,'hostname',gameinfo['hostname'])
        createTwoDict(data,i,'dbname',gamewebvar['dbNamePre']+str(i))
        createTwoDict(data,i,'redisport',gamewebvar['redisPort'] + int(gameinfo['insid']))
        createTwoDict(data,i,'targetredisport',gamewebvar['redisPort'] + int(targetinsid))
        createTwoDict(data,i,'sourceredisport',gamewebvar['redisPort'] + int(gameinfo['insid']))
        if(filterinsid.has_key(iplist[y])):
            filterinsid[iplist[y]] += str(targetinsid) + ','
        else:
            filterinsid[iplist[y]] = str(targetinsid) + ','
        #循环分配机器
        if(y > len(sidlist)):
            y = 0
    return data


#迁移game--生成新game信息
def createTransferGame(server):
    data = {}
    hostnamedict = {}
    for sid,val in server.items():
        outip = getOutip(val['targetip'])
        if(val['hostname']):
            hostname = val['hostname']
        else:
            hostname = createHostname()

        createTwoDict(data,sid,'sid',sid)
        createTwoDict(data,sid,'pid',val['pid'])
        createTwoDict(data,sid,'outIp',outip)
        createTwoDict(data,sid,'rootIp',gamewebvar['rootIp'])
        createTwoDict(data,sid,'hostName',hostname)
        createTwoDict(data,sid,'inSid',val['insid'])
        createTwoDict(data,sid,'platform',val['platform'])
        createTwoDict(data,sid,'inIp',val['targetip'])
        createTwoDict(data,sid,'redisPort',val['targetredisport'])
        createTwoDict(data,sid,'redisGlobalIp',gamewebvar['globalRedis'])
        createTwoDict(data,sid,'tcpPort',gamewebvar['tcpPort'] + val['insid'])
        createTwoDict(data,sid,'webPort',gamewebvar['webPort'] + val['insid'])
        createTwoDict(data,sid,'innerPort',gamewebvar['innerPort'] + val['insid'])

        #迁移服信息,迁移成功后删除game信息
        transfergameinfo = {"sid":sid,"redisPort":val['sourceredisport'],"inIp":val['inip'],\
        "dbUser":gamewebvar['dbUser'],"dbPwd":gamewebvar['dbPwd'],"dbName":gamewebvar['dbNamePre'] + str(sid)}
        createTwoDict(data,sid,'removegame',transfergameinfo)

    return data



#迁移后game中表的数据更新
def TransferGameStatus(server):
    sql = "SELECT server_id,in_ip,install_id FROM Serverinfo WHERE in_ip = '%s'"%(server['inIp'])
    cursor.execute(sql)
    row = cursor.fetchone()
    if(row):
        #老机器
        gameinfo = getDomainOutipSalt(server['inIp'])
        hostname  = gameinfo['hostname']
        outip = gameinfo['outip']
    else:
        #新机器
        outip = getOutip(server['inIp'])
        hostname = createHostname()

    sql = "UPDATE Serverinfo SET install_id = '%s',host_name = '%s',in_ip = '%s',out_ip = '%s' WHERE server_id = '%s'"%\
    (server['inSid'],hostname,server['inIp'],outip,server['sid'])
    cursor.execute(sql)


    
#迁移cross信息
def findTransferCrossinfo(platform,cid,sourceip,targetip):
    sql = "SELECT cross_id,in_ip FROM Crossinfo WHERE 1 = 1 "
    if(platform and cid):
        cidlist = ''
        for i in cid.split(','):
            cidlist += "'%s',"%(i)
        sql += " AND platform = '%s' AND cross_id IN(%s)"%(platform,cidlist[:-1])
    if(sourceip):
        sql += " AND in_ip = '%s'"%(sourceip)
    cursor.execute(sql)
    crossinfo = cursor.fetchall()

    #返回信息
    ret = ''
    # 迁移源机器
    iplist = []
    #迁移服id
    cidlist = ''
    for i in crossinfo:
        if(i[1] not in iplist):
            iplist.append(i[1])
        cidlist += '%s,'%(i[0])
        ret += 'game%s '%(i[0])

    ret += '共 <strong id="transfer">%s</strong> 个服迁移 '%(len(crossinfo))

    sql = 'SELECT * FROM Crossinfo WHERE 1=1 '
    #指定目标机器,迁移源和目标不能相同
    if(targetip and (targetip not in iplist)):
        sql += ' AND in_ip = "%s"'%(targetip)
        cursor.execute(sql)
        fetchall = cursor.fetchall()
        ret += '%s: 已配 <strong id="used">%s</strong> 个服 '%(targetip,len(fetchall))
        restnums = gamewebvar['allowInstallNum'] - len(fetchall)
        ret += '剩余 <strong id="restnums">%s</strong> 空位 '%(restnums) 
    else:
        # 未指定，优先分配到空位多的机器
        allowinstallip = findAllowinstallIp(platform,20,'')
        #删除和源机器相同的ip
        for i in iplist:
            if(allowinstallip.has_key(i)):
                allowinstallip.pop(i)
                continue
        
        for key,val in allowinstallip.items():
            targetip += '%s,'%(key)
        #迁移目标服ip
        targetip = targetip[:-1]
        #空位多的机器
        totalused  = 0
        for inip,used in allowinstallip.items():
            ret += '%s: 已配 <strong id="used">%s</strong> 个服 '%(inip,used)
            totalused += used
        restnums = gamewebvar['allowInstallNum']*len(allowinstallip) - totalused
        ret += '剩余 <strong id="restnums">%s</strong> 空位 '%(restnums)

    return {"msg":ret,"transfernum":len(crossinfo),"restnums":int(restnums),"sourcecid":cidlist[:-1],"targetip":targetip}     


#跨服subtype
def getSubtypeAndInip(cid):
    sql = "SELECT subType,in_ip FROM Crossinfo WHERE cross_id = '%s'"%(cid)
    cursor.execute(sql)
    row = cursor.fetchone()
    if(row):
        return {"subtype":row[0],"inip":row[1]}
    return {"subtype":"","inip":""}


#机器可用空位号
def getMaxCrossInstallId(inip,filterid=0):
    sql = "SELECT install_id FROM Crossinfo WHERE in_ip = '%s'"%(inip)
    cursor.execute(sql)
    fetchall = cursor.fetchall()
    from compiler.ast import flatten
    allowinstallnum = gamewebvar['allowInstallNum']
    if(None not in fetchall):
        for insid in range(1, (allowinstallnum + 1)):
            if(str(insid) in str(filterid).split(',')):
                continue
            if(insid not in flatten(fetchall)):
                return int(insid)
    return 1

    
#迁移cross--生成新cross信息
def createTransferCross(cid,targetip,platform):
    data = {}
    iplist = targetip.split(',')
    cidlist = cid.split(',')
    y = 0
    filterinsid = {}
    for i in cidlist:
        result = getSubtypeAndInip(i)
        if(filterinsid.has_key(iplist[y])):
            insid = getMaxCrossInstallId(iplist[y],filterinsid[iplist[y]])
        else:
            insid = getMaxCrossInstallId(iplist[y])
        createTwoDict(data,i,'cid',i) 
        createTwoDict(data,i,'subType',result['subtype'])
        createTwoDict(data,i,'inIp',iplist[y])
        createTwoDict(data,i,'platform',platform)
        createTwoDict(data,i,'redisGlobalIp',gamewebvar['globalRedis'])
        createTwoDict(data,i,'webPort',gamewebvar['crossWebPort'] + insid)
        createTwoDict(data,i,'innerPort',gamewebvar['crossInnerPort'] + insid)
        if(filterinsid.has_key(iplist[y])):
            filterinsid[iplist[y]] += str(insid) + ','
        else:
            filterinsid[iplist[y]] = str(insid) + ','
        if(y > len(cidlist)):
            y = 0 
        #迁移服信息,迁移成功后删除cross信息
        createTwoDict(data,i,'removecross',{'cid':i,'inIp':result['inip'],'inSid':insid})
    return data    
    


#迁移croos后，更新数据
def TransferCrossStatus(server):
    sql = "SELECT out_ip FROM Serverinfo WHERE in_ip = '%s'"%(server['inIp'])
    cursor.execute(sql)
    row = cursor.fetchone()
    if(row):
        outip = row[0]
    else:
        outip = getOutip(server['inIp'])
    sql = "UPDATE Crossinfo SET install_id = '%s',in_ip='%s',out_ip='%s' WHERE cross_id = '%s'"%\
          (server['removecross']['inSid'],server['inIp'],outip,server['cid'])
    cursor.execute(sql)



def findGameProcessInfo(platform,pid,inip):
    sql = "SELECT server_id,platform,platform_id,in_ip,out_ip,host_name FROM Serverinfo WHERE is_hf = 0 "
    if(platform):
        sql += " AND platform = '%s'"%(platform)
    if(pid):
        pidlist = ''
        for i in pid.split(','):
            pidlist += "'%s',"%(i)
        sql += " AND platform_id IN(%s)"%(pidlist[:-1])
    if(inip):
        sql += " AND in_ip = '%s'"%(inip)
    cursor.execute(sql)
    result = cursor.fetchall()
    data = {}
    gamestatuslist = getServiceStatus('game')
    for i in result:
        createTwoDict(data,i[0],'sid',i[0])
        createTwoDict(data,i[0],'platform',i[1])
        createTwoDict(data,i[0],'pid',i[2])
        createTwoDict(data,i[0],'inip',i[3])
        createTwoDict(data,i[0],'outip',i[4])
        createTwoDict(data,i[0],'hostname',i[5])
        if(gamestatuslist.has_key(str(i[0]))):
            gamestatus = gamestatuslist[str(i[0])]
        else:
            gamestatus = 2
        createTwoDict(data,i[0],'status',gamestatus)

    return data


#获取game,cross运行状态
def getServiceStatus(mod):
    #import redis
    from baseFun import sshCmd
    ret = sshCmd(gamewebvar['globalRedis'],'redis-cli -p 6380 HGETALL %s'%(mod))
    strsplit = ret.split('\n')
    data = {}
    for i in range(len(strsplit)):
        if( i > 0 and i % 2 !=0 ):
            server = eval(strsplit[i])
            data[strsplit[i-1]] = server['status']
    return data



#game启服,停服sid
def findSidForGameProcess(platform,pid,inip):
    sql = "SELECT server_id,in_ip FROM Serverinfo WHERE is_hf = 0 "
    if(platform):
        sql += " AND platform = '%s'"%(platform)
    if(pid):
        pidlist = ''
        for i in pid.split(','):
            pidlist += "'%s',"%(i)
        sql += " AND platform_id IN(%s)"%(pidlist[:-1])
    if(inip):
        sql += " AND in_ip = '%s'"%(inip)
    cursor.execute(sql)
    result = cursor.fetchall()
    data = {}
    for i in result:
        if(data.has_key(i[1])):
            data[i[1]] = '%s,%s'%(data[i[1]],i[0])
        else:
            data[i[1]] = i[0]
    return data


#cross启服,停服信息
def findCrossProcessInfo(platform,cid,inip):
    sql = "SELECT cross_id,platform,in_ip,subType,out_ip FROM Crossinfo WHERE 1 = 1 "
    if(platform):
        sql += " AND platform = '%s'"%(platform)
    if(cid):
        cidlist = ''
        for i in cid.split(','):
            cidlist += "'%s',"%(i)
        sql += " AND cross_id IN(%s)"%(cidlist[:-1])
    if(inip):
        sql += " AND in_ip = '%s'"%(inip)
    cursor.execute(sql)
    result = cursor.fetchall()
    data = {}
    crossstatuslist = getServiceStatus('cross')
    for i in result:
        createTwoDict(data,i[0],'cid',i[0])
        createTwoDict(data,i[0],'platform',i[1])
        createTwoDict(data,i[0],'inip',i[2])
        createTwoDict(data,i[0],'subtype',i[3])
        createTwoDict(data,i[0],'outip',i[4])
        if(crossstatuslist.has_key(str(i[0]))):
            crossstatus = crossstatuslist[str(i[0])]
        else:
            crossstatus = 2
        createTwoDict(data,i[0],'status',crossstatus)

    return data


##cross启服,停服cid
def findCidForCrossProcess(platform,cid,inip):
    sql = "SELECT cross_id,in_ip FROM Crossinfo WHERE 1 = 1 "
    if(platform):
        sql += " AND platform = '%s'"%(platform)
    if(cid):
        cidlist = ''
        for i in cid.split(','):
            cidlist += "'%s',"%(i)
        sql += " AND cross_id IN(%s)"%(cidlist[:-1])
    if(inip):
        sql += " AND in_ip = '%s'"%(inip)
    cursor.execute(sql)
    result = cursor.fetchall()
    data = {}
    for i in result:
        if(data.has_key(i[1])):
            data[i[1]] = '%s,%s'%(data[i[1]],i[0])
        else:
            data[i[1]] = i[0]
    return data



#更改用户权限
def updateUserPermission(uname,uid,perids):
    from django.contrib.auth.models import Permission, User
    sql = "DELETE FROM auth_user_user_permissions WHERE user_id = '%s'"%(uid)
    cursor.execute(sql)
    for pid in perids:
        User.objects.get(username=uname).user_permissions.add(pid)



#用户所有权限
def userAllPermission(uname):
    from django.contrib.auth.models import Permission, User
    permission = User.objects.get(username=uname).user_permissions.values('name')
    pername = ''
    for val in permission:
        pername += str(val['name']) + ','
    return pername



#删除管理员
def deleteAccount(uid):
    sql = "DELETE FROM auth_user WHERE id = '%s'"%(uid)
    cursor.execute(sql)


#game运行状态
def serviceRunInfo():
    gamestatus = getServiceStatus('game')
    total,right,error = 0,0,0
    gameerror = ''

    sql = 'SELECT server_id FROM Serverinfo WHERE is_hf = 0'
    cursor.execute(sql)
    result = cursor.fetchall()
    for sid in result:
        total += 1
        if(gamestatus.has_key(str(sid[0]))):
            right += 1
        else:
            error += 1
            gameerror += 'game%s '%(sid[0])
    data = {}
    data['gamestatus'] = '共 <strong>%s</strong> 个服 &nbsp;&nbsp;&nbsp; 正常运行 <strong>%s</strong> 个服 &nbsp;&nbsp;&nbsp;\
    停服或异常 <strong class="text-danger">%s</strong> 个服'%(total,right,error)
    if(gameerror):
        data['gameerror'] = '<strong class="text-danger"> 停止运行状态: %s</strong>'%(gameerror)

    crossstatus = getServiceStatus('cross')
    total,right,error = 0,0,0
    crosserror = ''

    sql = 'SELECT cross_id FROM Crossinfo'
    cursor.execute(sql)
    result = cursor.fetchall()
    for cid in result:
        total += 1
        if(crossstatus.has_key(str(cid[0])) and crossstatus[str(cid[0])] == 0):
            right += 1
        else:
            error += 1
            crosserror += 'cross%s '%(cid[0])    

    data['crossstatus'] = '共 <strong>%s</strong> 个服 &nbsp;&nbsp;&nbsp; 正常运行 <strong>%s</strong> 个服 &nbsp;&nbsp;&nbsp;\
    停服或异常 <strong class="text-warning">%s</strong> 个服'%(total,right,error)
    if(crosserror):
        data['crosserror'] = '<strong class="text-warning"> 停止运行状态: %s</strong>'%(crosserror)    
    return data


#获取当前脚本的日志
def scriptLog(user):
    from webgame.settings import BASE_DIR
    logpath = BASE_DIR + '/logs/%s.log'%(user)
    fobj = open(logpath,'r')
    logstr = []
    pos = 0
    if(os.path.exists(logpath) and os.path.getsize(logpath) > 0):
        #从文件尾部读取文件
        while True:
            pos = pos - 1
            fobj.seek(pos, 2)
            #日志分割符&
            firstline = fobj.tell()
            if fobj.read(1) == '&' or firstline < 1:
                for row in [line.strip() for line in fobj.readlines()]:
                    log = tanslateColor(row)
                    logstr.append(log)
                break
    return logstr


#标签转颜色
def tanslateColor(strval):
    tempstr = strval.replace('[31m','<strong style="color:red">')
    tempstr = tempstr.replace('[32m','<strong style="color:green">')
    tempstr = tempstr.replace('[0m','</strong>')
    return '<p>' + tempstr + '</p>'
