#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
安装cross
'''
import sys
import baseFun
import commands
import tarForInstall


def install(user,server):
    #日志分割符
    baseFun.writelog(user,'&&')
    #打包源程序文件
    msg = tarForInstall.tarFile()
    baseFun.writelog(user,msg['msg'])
    if(msg['status'] == 500):
        return False

    #安装
    for key,val in server.items():
        script = 'cd /data/pythonscript;./crossInstall.py "%s"'%(val)
        ret = baseFun.sshCmd(val['inIp'],script)
        msg = eval(ret)
        baseFun.writelog(user,msg['msg'])
        if(msg['status'] == 500):
            return False
