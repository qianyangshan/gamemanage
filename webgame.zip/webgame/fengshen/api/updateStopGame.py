#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
更新第二步 停game
'''
import baseFun
import multiprocessing

def stop(user,ip,sid):
    baseFun.writelog(user,'&&')
    script = 'cd /data/pythonscript;./serviceGameStop.py %s'%(sid)
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg']) 
    

def stopGame(user,iplist):
    baseFun.writelog(user,'&&')
    pool = multiprocessing.Pool(processes=len(iplist))
    for inip,sid in iplist.items():
        pool.apply_async(stop, (user,inip,sid))
    pool.close()
    pool.join()

    baseFun.writelog(user,'[32m game stop finished[0m')
