#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
迁移game
'''
import os
import sys
import baseFun
import commands
from webgame.settings import gamewebvar

def mysqlAndRedis(user,server):
    baseFun.writelog(user,'&&')
    if(not os.path.exists(gamewebvar['redisDump'])):
        baseFun.writelog(user,"[31mplease install redis-dump tools[0m")
        return False
    for sid,val in server.items():
        #停服
        baseFun.writelog(user,'正在停服.......')
        inip = val['inip']
        script = "cd /data/pythonscript;./serviceGameStop.py %s"%(sid)
        ret = baseFun.sshCmd(inip,script)
        msg = eval(ret)
        baseFun.writelog(user,msg['msg'])
        if(msg['status'] == 500):
            return False
        
        #导出迁移game数据库
        baseFun.writelog(user,'正在迁移数据库,redis.......')
        sqlfile = gamewebvar['cache'] + val['dbname'] + '.sql'
        script = 'mysqldump -u%s -h%s -p%s %s > %s'%(gamewebvar['dbUser'],inip,gamewebvar['dbPwd'],val['dbname'],sqlfile)
        (status,output) = commands.getstatusoutput(script)
        if('error' in output):
            baseFun.writelog(user,output)
            return False
        
        #导出迁移game的redis库
        redisname = gamewebvar['cache'] + 'redis_%s.txt'%(sid)
        script = 'redis-dump -u %s:%s -d 0 > %s'%(inip,val['redisport'],redisname)
        (status,output) = commands.getstatusoutput(script)
        if(status != 0):
            msg = "[31m%s redisdump: %s[0m"%(redisname,output)
            baseFun.writelog(user,msg)
        
        #数据库导入到目标IP
        script = 'mysql -u%s -h%s -p%s -e "create database if not exists %s default charset utf8 COLLATE utf8_general_ci"'%\
        (gamewebvar['dbUser'],val['targetip'],gamewebvar['dbPwd'],val['dbname'])
        (status,output) = commands.getstatusoutput(script)
        if('error' in output):
            baseFun.writelog(user,output)
            return False
        script = 'mysql -u%s -h%s -p%s %s < %s'%(gamewebvar['dbUser'],val['targetip'],gamewebvar['dbPwd'],val['dbname'],sqlfile)
        (status,output) = commands.getstatusoutput(script)
        if('error' in output):
            baseFun.writelog(user,output)
            return False
        baseFun.writelog(user,'%s transfer success'%(val['dbname']))
         
        #redis库导入到目标IP
        script = "cd /data/pythonscript;./clearRedis.py '%s'"%(val['targetredisport'])
        baseFun.sshCmd(val['targetip'],script)
        script = "< %s redis-load -u %s:%s"%(redisname,val['targetip'],val['targetredisport'])
        (status,output) = commands.getstatusoutput(script)
        if(status != 0):
            msg = "[31m%s redis load: %s[0m"%(redisname,output)
            baseFun.writelog(user,msg)
        baseFun.writelog(user,'redis%s transfer success'%(sid))
        
        

def createGame(user,server):
    if(not os.path.exists(gamewebvar['redisDump'])):
        return False

    for sid,val in server.items():
        baseFun.writelog(user,'正在迁移程序文件.......')
        script = 'cd /data/pythonscript;./createGame.py "%s"'%(val)
        ret = baseFun.sshCmd(val['inIp'],script)
        msg = eval(ret)
        baseFun.writelog(user,msg['msg'])
        if(msg['status'] == 200):
            script = 'cd /data/pythonscript;./removeGame.py "%s"'%(val['removegame'])
            ret = baseFun.sshCmd(val['removegame']['inIp'],script)
            #更新表数据
            from fengshen.models import TransferGameStatus
            TransferGameStatus(val)
        if(msg['status'] == 500):
         return False 
