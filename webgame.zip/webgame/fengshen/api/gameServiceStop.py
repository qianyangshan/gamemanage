#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
停服game
'''
import baseFun
import multiprocessing

def stop(user,ip,sid):
    '''
    baseFun.writelog(user,'&&')
    script = 'cd /data/pythonscript;./serviceGameStop.py %s'%(sid)
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg']) 
    '''
    

def gameStop(user,iplist):
    baseFun.writelog(user,'&&')
    pool = multiprocessing.Pool(processes=len(iplist))
    for inip,sid in iplist.items():
        pool.apply_async(stop, (user,inip,sid))
    pool.close()
    pool.join()
