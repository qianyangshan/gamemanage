//定时器
var timeobj


//新服配服
$('#addnewgamesubmit').click(function(){
    if( ! confirm('确认添加新服?')) {
    	return false;
    }
    
	var platform = $("#pt").find("option:selected").val();
	if(platform == undefined) {
		platform = $("#pt").val();
	}
	var inip = $("#inip").val();
    var installnum = $("#installnum").val();
    if(installnum == '' || platform == '' || inip == '') {
    	showmsg('请确证输入框填写完整');
    }
	
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'platform':platform,'installnum':installnum,'inip':inip,'mod':'creategame'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
       	    showmsg(data);
       },
	});    
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;    
});



// 老服配服
$('#installgamesubmit').click( function () {
    if( ! confirm('确认配服?')) {
    	return false;
    }
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'platform':platform,'installnum':installnum,'inip':inip,'mod':'creategameagain'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
       	    showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});


//跨服配服
$('#addcrosssubmit').click(function(){
    if( ! confirm('确认添加跨服?')) {
    	return false;
    }
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'platform':platform,'installnum':installnum,'inip':inip,'subtype':subtype,'mod':'createcross'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
       	    showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;	
	
});


/**
**  版本更新
**  第一步 上传文件
**/

//拉取最新程序文件到运维管理机
$('#pullnewtar').click(function(){
	$(this).text('正在拉取，请稍等....');
	$(this).attr('disabled','disabled');
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'pullnewtar'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
       	    if(parseInt(data) != 200) {
       	    	showmsg('拉取更新文件错误');
       	    	return false;
       	    }
       	    window.location.reload();
       },
	});
});

//分发文件
$('#uploadsubmit').click(function(){
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'uploadfile'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;	
});


//更新第二步 停服
$('#stopservicedsubmit').click(function(){
    if( ! confirm('确认停game,cross?')) {
    	return false;
    }	
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'stopservice'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});


//更新第三步 更新game
$('#updategamesubmit').click(function(){
    if( ! confirm('确认更新game?')) {
    	return false;
    }	
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'updategame'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});


//更新第四步 更新cross
$('#updatecrosssubmit').click(function(){
    if( ! confirm('确认更新cross?')) {
    	return false;
    }	
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'updatecross'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});


//更新第五步 更新data
$('#updatedatasubmit').click(function(){
    if( ! confirm('确认更新data?')) {
    	return false;
    }	
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'updatedata'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});


//更新第六步 开启服务
$('#startservicesubmit').click(function(){
    if( ! confirm('确认开启服务?')) {
    	return false;
    }	
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'startservice'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});

//移除已合game
$('#removegamesubmit').click(function(){
    if( ! confirm('确认删除合服?')) {
    	return false;
    }
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'removemergegame'},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});


//迁移game
$('#transfergamesubmit').click(function(){
    if( ! confirm('确认迁移game?')) {
    	return false;
    }
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'transfergame','sourcesid':sourcesid,'targetip':targetip},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});


//迁移cross
$('#transfercrosssubmit').click(function(){
    if( ! confirm('确认迁移cross?')) {
    	return false;
    }
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'transfercross','sourcecid':sourcecid,'targetip':targetip,'platform':platform},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("showlog()","5000");
	return false;
});


//game启服
$('#gamepstartubmit').click(function(){
    if( ! confirm('确认开启game?')) {
    	return false;
    }
    $('.gamestatus').hide();
    $('.gamestarttips').show();
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'gamestart','inip':inip,'pid':pid,'platform':platform},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("servicestatus('game','start')","10000");
	return false;
});


//game停服
$('#gamepstopubmit').click(function(){
    if( ! confirm('确认停止game?')) {
    	return false;
    }
    $('.gamestatus').hide();
    $('.gamestoptips').show();    
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'gamestop','inip':inip,'pid':pid,'platform':platform},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("servicestatus('game','stop')","10000");
	return false;
});


//cross启服
$('#crosspstartsubmit').click(function(){
    if( ! confirm('确认开启cross?')) {
    	return false;
    }
    $('.crossstatus').hide();
    $('.crossstarttips').show();
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'crossstart','inip':inip,'cid':cid,'platform':platform},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("servicestatus('cross','start')","10000");
	return false;
});


//cross停服
$('#crosspstopsubmit').click(function(){
    if( ! confirm('确认停止cross?')) {
    	return false;
    }
    $('.crossstatus').hide();
    $('.crossstoptips').show();
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'crossstop','inip':inip,'cid':cid,'platform':platform},
	　　dataType: 'text',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
           showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	timeobj = setInterval("servicestatus('cross','stop')","10000");
	return false;
});


//game,cross 开启,停止状态检查
function servicestatus(service,op){
	var id = ''
	ids = id.substr(0,(id.length-1));
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod': 'servicestatus', 'service': service},
	　　dataType: 'json',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
       	   //
           $('.serviceid').each(function(){
		       id = $(this).attr('val');
		       if(op == 'start' && data[id] == 0) {
		           $('#'+service+'starttips_' + id).hide();
		           $('#'+service+'start_' + id).show();
		       }
		       if(op == 'stop' && data[id] == 2) {
		           $('#'+service+'stoptips_' + id).hide();
		           $('#'+service+'stop_' + id).show();
		       }
	       });
       },
   }); 	
}



//服务器初始化
$('#initserversubmit').click(function(){
	var inip = $("#inip").val();
	var pwd = $("#pwd").val();
	if(inip == '' || pwd == '') {
		showmsg('输入项不完整');
	}
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'initserver','pwd':pwd,'inip':inip},
	　　dataType: 'html',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
       	    showmsg(data);
       },
	});
	$(this).attr('disabled',true);
	//timeobj = setInterval("showlog()","10000");
	return false;	
});



// 脚本日志
function showlog(){
	$('#scriptlog').show('slow');
	$.ajax({
	　　url: '/execscript/',
	　　timeout : 0,
	　　type : 'post',
	　　data : {'mod':'showlog'},
	　　dataType: 'html',
	　　statusCode: {500: function() {
	　　    showmsg('服务器内服错误，请联系程序员处理');
       }},
       success: function(data){
       	    $('#logcontent').html(data);
       },
	});	
}



//subtype选择效果
$('.subtype').each(function(){
	$(this).click(function(){
		$('a').removeClass('btn-palegreen');
	    $(this).addClass('btn-palegreen');
	    var val = $(this).attr('data');
	    $('input[name=subtype]').val(val);
	});
});


//提示信息
function showmsg(msg) {
    if(msg) {
    	$('.modal-body').html(msg);
	    $(function () { $('#myModal').modal({
		    keyboard: true
	    })});
	    return false;
    }
}
showmsg(msg);

//添加新服输入框
$('#addptfm').click(function(){
	$('#pt').remove();
	$(this).parent('span').prepend('<input id="pt" class="form-control" autocomplete="off" tpye="input">');
});