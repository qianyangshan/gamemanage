#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
迁移cross
'''
import sys
import baseFun
import commands
import tarForInstall


def createCross(user,server):
    #日志分割符
    baseFun.writelog(user,'&&')
    #打包源程序文件
    msg = tarForInstall.tarFile()
    baseFun.writelog(user,msg['msg'])
    if(msg['status'] == 500):
        return False

    for cid,val in server.items():
        script = 'cd /data/pythonscript;./createCross.py "%s"'%(val)
        ret = baseFun.sshCmd(val['inIp'],script)
        msg = eval(ret)
        baseFun.writelog(user,msg['msg'])
        if(msg['status'] == 500):
            return False
        else:
            #迁移成功更新
            script = 'cd /data/pythonscript;./removeCross.py "%s"'%(val['removecross'])
            ret = baseFun.sshCmd(val['removecross']['inIp'],script)
            #更新表数据
            from fengshen.models import TransferCrossStatus
            TransferCrossStatus(val) 
