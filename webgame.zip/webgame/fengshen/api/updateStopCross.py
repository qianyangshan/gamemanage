#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
更新第二步 停cross
'''
import baseFun
import multiprocessing


def stop(user,ip,cid):
    script = 'cd /data/pythonscript;./serviceCrossStop.py %s'%(cid)
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg']) 
    

def stopCross(user,iplist):
    pool = multiprocessing.Pool(processes=len(iplist))
    for inip,cid in iplist.items():
        pool.apply_async(stop, (user,inip,cid))
    pool.close()
    pool.join()

    baseFun.writelog(user,'[32m cross stop finished[0m')
