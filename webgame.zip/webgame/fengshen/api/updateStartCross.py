#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
更新第六步 开启cross
'''
import baseFun
import multiprocessing


def start(user,ip,cid):
    script = 'cd /data/pythonscript;./serviceCrossStart.py %s'%(cid)
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg']) 


def startCross(user,iplist):
    pool = multiprocessing.Pool(processes=len(iplist))
    for inip,cid in iplist.items():
        pool.apply_async(start, (user,inip,cid))
    pool.close()
    pool.join()

    baseFun.writelog(user,'[32m cross start finished[0m')
