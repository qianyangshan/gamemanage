#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
更新第三步 更新game
'''
import baseFun
import multiprocessing

def update(user,ip,sid):
    baseFun.writelog(user,'&&')
    script = 'cd /data/pythonscript;./updateGame.py %s'%(sid)
    ret= baseFun.sshCmd(ip,script)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg'])
    

def updateFile(user,iplist):
    baseFun.writelog(user,'&&')
    pool = multiprocessing.Pool(processes=len(iplist))
    for inip,sid in iplist.items():
        pool.apply_async(update, (user,inip,sid))
    pool.close()
    pool.join()

    baseFun.writelog(user,'[32m game update finished[0m')

