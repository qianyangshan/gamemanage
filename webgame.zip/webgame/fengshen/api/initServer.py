#!/usr/bin/python2.7
# -*- coding: utf-8 -*-
'''
服务器初始化
'''
import sys
import baseFun
import multiprocessing

def init(user,pwd,inip):
    #上传初始化程序文件压缩包
    
    ret = baseFun.uploadFileForInitServer(pwd,inip)
    msg = eval(ret)
    baseFun.writelog(user,msg['msg'])
    if(msg['status'] == 500):
        return False
    #运行初始化脚本
    script = 'cd /root/software;sh init_install.sh'
    baseFun.sshCmd(inip,script)
    
    #初始化检查
    baseFun.writelog(user,'[32m%s init log[0m'%(inip))
    script = "netstat -ntlp | grep -E \'nginx|mysqld|java\'"
    ret = baseFun.sshCmd(inip,script)
    for i in ['nginx','mysqld','java']:
        if(i in ret):
            baseFun.writelog(user,'%s install success'%(i))
    script = 'ls /etc/redis/'
    ret = baseFun.sshCmd(inip,script)
    if('6901.conf' in ret):
        baseFun.writelog(user,'redis install success')
    


def initService(user,pwd,iplist):
    baseFun.writelog(user,'&&')
    baseFun.writelog(user,'正在初始化，请耐心等待......')
    pool = multiprocessing.Pool(processes=len(iplist))
    for inip in iplist:
        pool.apply_async(init, (user,pwd,inip))
    pool.close()
    pool.join()
