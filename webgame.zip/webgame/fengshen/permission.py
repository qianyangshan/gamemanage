#!/usr/bin/python2.7
# -*- coding: utf-8 -*-

from fengshen.models import userAllPermission
from django.http import HttpResponseRedirect


#用户是否拥有当前操作权限
def perm_check(request, *args, **kwargs):
     userperm = userAllPermission(request.user)
     userpermlist = userperm.split(',')
     for perm in userpermlist:
         if(perm in request.path and perm !=''):
             return True
     return False 


def permission_required(fun):
    def per(request, *args, **kwargs):
        if perm_check(request, *args, **kwargs):
            return fun(request, *args, **kwargs)
        return HttpResponseRedirect('/main/')
    return per
